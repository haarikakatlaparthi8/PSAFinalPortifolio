const carouselSlide = document.querySelector(".carousel-slide");
const carouselSlides = document.querySelectorAll(".c-item");


const prevBtn = document.querySelector("#prevBtn");
const nextBtn = document.querySelector("#nextBtn");

let counter = 1;
const size = carouselSlides[0].clientWidth;

carouselSlide.style.transform = "translateX(" + (-size * counter) + "px)";

// Button listeners
nextBtn.addEventListener("click", () => {
    if (counter >= carouselSlides.length - 1) {
        return;
    }
    carouselSlide.style.transition = "transform 1s ease-in-out";
    counter++;
    // console.log(counter);
    carouselSlide.style.transform = "translateX(" + (-size * counter) + "px)";
});

prevBtn.addEventListener("click", () => {
    if (counter <= 0) {
        return;
    }
    carouselSlide.style.transition = "transform 1s ease-in-out";
    counter--;
    // console.log(counter);
    carouselSlide.style.transform = "translateX(" + (-size * counter) + "px)";
});



carouselSlide.addEventListener("transitionend", () => {
    if (carouselSlides[counter].id === "lastClone") {
        carouselSlide.style.transition = "none";
        counter = carouselSlides.length - 2;
        carouselSlide.style.transform = "translateX(" + (-size * counter) + "px)";   
    }

    if (carouselSlides[counter].id === "firstClone") {
        carouselSlide.style.transition = "none";
        counter = carouselSlides.length - counter;
        carouselSlide.style.transform = "translateX(" + (-size * counter) + "px)";   
    }

});